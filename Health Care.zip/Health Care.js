// Check out the latest docs here: https://portal.thirdweb.com/typescript/v5/storage

import { upload } from "thirdweb/storage";

// Here we get the IPFS URI of where our metadata has been uploaded
const uri = await upload({
  client,
  files: [
    new File(["hello world"], "hello.txt"),
  ],
});

// This will log a URL like ipfs://QmWgbcjKWCXhaLzMz4gNBxQpAHktQK6MkLvBkKXbsoWEEy/0
console.info(uri);

// Here we a URL with a gateway that we can look at in the browser
const url = await download({
  client,
  uri,
}).url;

// This will log a URL like https://ipfs.thirdwebstorage.com/ipfs/QmWgbcjKWCXhaLzMz4gNBxQpAHktQK6MkLvBkKXbsoWEEy/0
console.info(url);